import CompanyHero from './components/CompanyHero';
import AboutCompany from './components/AboutCompany';
import CompanyStructure from './components/CompanyStructure';
import WorkDepartments from './components/WorkDepartments';
import ContactFooter from './components/ContactFooter';

export default function App() {
  return (
    <div className="min-h-screen">
      <CompanyHero />
      <AboutCompany />
      <CompanyStructure />
      <WorkDepartments />
      <ContactFooter />
    </div>
  );
}