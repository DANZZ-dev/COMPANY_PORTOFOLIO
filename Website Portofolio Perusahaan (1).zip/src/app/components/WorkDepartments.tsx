import { Code, Megaphone, TrendingUp, Users, Shield, Headphones } from 'lucide-react';
import { motion } from 'motion/react';
import { useInView } from 'motion/react';
import { useRef } from 'react';

const departments = [
  {
    icon: Code,
    title: "Divisi Teknologi & Pengembangan",
    description: "Bertanggung jawab atas pengembangan produk, infrastruktur IT, dan inovasi teknologi.",
    teams: ["Software Development", "Quality Assurance", "DevOps", "UI/UX Design"]
  },
  {
    icon: Megaphone,
    title: "Divisi Pemasaran & Penjualan",
    description: "Mengelola strategi pemasaran, branding, dan hubungan dengan klien.",
    teams: ["Digital Marketing", "Sales", "Business Development", "Brand Management"]
  },
  {
    icon: Users,
    title: "Divisi SDM & Umum",
    description: "Mengelola sumber daya manusia, recruitment, dan administrasi perusahaan.",
    teams: ["Recruitment", "Training & Development", "Employee Relations", "General Affairs"]
  },
  {
    icon: TrendingUp,
    title: "Divisi Keuangan & Akuntansi",
    description: "Mengelola keuangan perusahaan, pelaporan, dan analisis finansial.",
    teams: ["Accounting", "Financial Planning", "Tax & Compliance", "Internal Audit"]
  },
  {
    icon: Shield,
    title: "Divisi Keamanan & Kepatuhan",
    description: "Memastikan keamanan data dan kepatuhan terhadap regulasi.",
    teams: ["Cybersecurity", "Data Protection", "Risk Management", "Compliance"]
  },
  {
    icon: Headphones,
    title: "Divisi Layanan Pelanggan",
    description: "Memberikan dukungan dan layanan terbaik kepada klien.",
    teams: ["Customer Support", "Technical Support", "Account Management", "Client Success"]
  }
];

export default function WorkDepartments() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section className="py-20 px-6 bg-background" ref={ref}>
      <div className="max-w-7xl mx-auto">
        <motion.div
          className="text-center mb-16"
          initial={{ y: 30, opacity: 0 }}
          animate={isInView ? { y: 0, opacity: 1 } : { y: 30, opacity: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl mb-4">Divisi & Departemen</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Tim profesional yang terorganisir dengan baik untuk memberikan layanan terbaik
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {departments.map((dept, idx) => {
            const Icon = dept.icon;
            return (
              <motion.div
                key={idx}
                className="bg-card border border-border rounded-lg p-6"
                initial={{ y: 50, opacity: 0 }}
                animate={isInView ? { y: 0, opacity: 1 } : { y: 50, opacity: 0 }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                whileHover={{
                  y: -8,
                  boxShadow: "0 25px 50px -12px rgb(0 0 0 / 0.25)",
                  transition: { duration: 0.3 }
                }}
              >
                <motion.div
                  className="bg-primary/10 w-14 h-14 rounded-lg flex items-center justify-center mb-4"
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.6 }}
                >
                  <Icon className="w-7 h-7 text-primary" />
                </motion.div>

                <h3 className="mb-3">{dept.title}</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  {dept.description}
                </p>

                <div className="border-t border-border pt-4">
                  <p className="text-xs mb-2 opacity-70">Tim:</p>
                  <div className="flex flex-wrap gap-2">
                    {dept.teams.map((team, teamIdx) => (
                      <motion.span
                        key={teamIdx}
                        className="text-xs bg-muted px-2 py-1 rounded"
                        whileHover={{ scale: 1.1 }}
                        transition={{ duration: 0.2 }}
                      >
                        {team}
                      </motion.span>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
