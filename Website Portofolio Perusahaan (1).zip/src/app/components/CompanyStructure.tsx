import { Users, UserCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { useInView } from 'motion/react';
import { useRef } from 'react';

const structure = [
  {
    level: 1,
    title: "Direktur Utama",
    name: "NAMA",
  },
  {
    level: 2,
    positions: [
      { title: "Direktur Operasional", name: "NAMA" },
      { title: "Direktur Keuangan", name: "NAMA" },
      { title: "Direktur Teknologi", name: "NAMA" },
    ]
  },
  {
    level: 3,
    positions: [
      { title: "Manajer HRD", name: "NAMA" },
      { title: "Manajer Pemasaran", name: "NAMA" },
      { title: "Manajer Produksi", name: "NAMA" },
      { title: "Manajer IT", name: "NAMA" },
    ]
  }
];

export default function CompanyStructure() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section className="py-20 px-6 bg-muted/30" ref={ref}>
      <div className="max-w-6xl mx-auto">
        <motion.div
          className="text-center mb-16"
          initial={{ y: 30, opacity: 0 }}
          animate={isInView ? { y: 0, opacity: 1 } : { y: 30, opacity: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl mb-4">Struktur Organisasi</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Struktur organisasi yang solid dengan kepemimpinan yang berpengalaman
          </p>
        </motion.div>

        <div className="space-y-8">
          {/* Level 1 - CEO */}
          <div className="flex justify-center">
            <motion.div
              className="bg-primary text-primary-foreground p-6 rounded-lg shadow-lg w-72 text-center"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={isInView ? { scale: 1, opacity: 1 } : { scale: 0.8, opacity: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ scale: 1.05, boxShadow: "0 20px 25px -5px rgb(0 0 0 / 0.2)" }}
            >
              <UserCircle className="w-12 h-12 mx-auto mb-3" />
              <h3 className="mb-1">{structure[0].title}</h3>
              <p className="text-sm opacity-90">{structure[0].name}</p>
            </motion.div>
          </div>

          {/* Connector Line */}
          <div className="flex justify-center">
            <div className="w-0.5 h-8 bg-border"></div>
          </div>

          {/* Level 2 - Directors */}
          <div className="flex justify-center gap-4">
            {structure[1].positions?.map((pos, idx) => (
              <motion.div
                key={idx}
                className="relative"
                initial={{ y: 30, opacity: 0 }}
                animate={isInView ? { y: 0, opacity: 1 } : { y: 30, opacity: 0 }}
                transition={{ duration: 0.5, delay: 0.4 + idx * 0.1 }}
              >
                {idx > 0 && (
                  <div className="absolute -left-2 top-1/2 w-4 h-0.5 bg-border -translate-x-full"></div>
                )}
                <motion.div
                  className="bg-card border border-border p-5 rounded-lg shadow-md w-56 text-center"
                  whileHover={{ y: -5, boxShadow: "0 20px 25px -5px rgb(0 0 0 / 0.1)" }}
                  transition={{ duration: 0.2 }}
                >
                  <Users className="w-10 h-10 mx-auto mb-2 text-primary" />
                  <h4 className="mb-1">{pos.title}</h4>
                  <p className="text-sm text-muted-foreground">{pos.name}</p>
                </motion.div>
              </motion.div>
            ))}
          </div>

          {/* Connector Lines */}
          <div className="flex justify-center gap-4">
            {structure[1].positions?.map((_, idx) => (
              <div key={idx} className="w-56 flex justify-center">
                <div className="w-0.5 h-8 bg-border"></div>
              </div>
            ))}
          </div>

          {/* Level 3 - Managers */}
          <div className="flex justify-center gap-4">
            {structure[2].positions?.map((pos, idx) => (
              <motion.div
                key={idx}
                className="bg-card border border-border p-4 rounded-lg shadow w-52 text-center"
                initial={{ y: 30, opacity: 0 }}
                animate={isInView ? { y: 0, opacity: 1 } : { y: 30, opacity: 0 }}
                transition={{ duration: 0.5, delay: 0.8 + idx * 0.1 }}
                whileHover={{ y: -5, boxShadow: "0 20px 25px -5px rgb(0 0 0 / 0.1)" }}
              >
                <Users className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                <h4 className="mb-1 text-sm">{pos.title}</h4>
                <p className="text-xs text-muted-foreground">{pos.name}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
