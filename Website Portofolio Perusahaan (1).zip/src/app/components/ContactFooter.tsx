import { Mail, Phone, MapPin, Facebook, Instagram, Linkedin, Twitter } from 'lucide-react';
import { motion } from 'motion/react';
import { useInView } from 'motion/react';
import { useRef } from 'react';

const socialMedia = [
  { icon: Facebook, name: "Facebook", url: "#", color: "hover:text-blue-600" },
  { icon: Instagram, name: "Instagram", url: "#", color: "hover:text-pink-600" },
  { icon: Linkedin, name: "LinkedIn", url: "#", color: "hover:text-blue-700" },
  { icon: Twitter, name: "Twitter", url: "#", color: "hover:text-sky-500" },
];

const contactInfo = [
  {
    icon: MapPin,
    title: "Alamat",
    content: "Jl. Sudirman No. 123, Jakarta Pusat 10220, Indonesia"
  },
  {
    icon: Phone,
    title: "Telepon",
    content: "+62 21 1234 5678"
  },
  {
    icon: Mail,
    title: "Email",
    content: "EMAILPERUSAHAAN@GMAIL.COM"
  }
];

export default function ContactFooter() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <footer className="bg-primary text-primary-foreground" ref={ref}>
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Company Info */}
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={isInView ? { y: 0, opacity: 1 } : { y: 30, opacity: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="text-2xl mb-4">NAMA PERUSAHAAN</h3>
            <p className="opacity-90 leading-relaxed">
              DESKRIPSI PERUSAHAAN/MOTTO PERUSAHAAN
            </p>
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={isInView ? { y: 0, opacity: 1 } : { y: 30, opacity: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h4 className="mb-6">Hubungi Kami</h4>
            <div className="space-y-4">
              {contactInfo.map((info, idx) => {
                const Icon = info.icon;
                return (
                  <motion.div
                    key={idx}
                    className="flex items-start gap-3"
                    whileHover={{ x: 5 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Icon className="w-5 h-5 mt-0.5 opacity-80" />
                    <div>
                      <p className="text-sm opacity-70 mb-1">{info.title}</p>
                      <p className="text-sm">{info.content}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>

          {/* Social Media */}
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={isInView ? { y: 0, opacity: 1 } : { y: 30, opacity: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <h4 className="mb-6">Ikuti Kami</h4>
            <div className="flex gap-4">
              {socialMedia.map((social, idx) => {
                const Icon = social.icon;
                return (
                  <motion.a
                    key={idx}
                    href={social.url}
                    aria-label={social.name}
                    className={`bg-primary-foreground/10 w-12 h-12 rounded-lg flex items-center justify-center ${social.color}`}
                    whileHover={{ y: -5, scale: 1.1 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Icon className="w-5 h-5" />
                  </motion.a>
                );
              })}
            </div>

            <div className="mt-8">
              <h4 className="mb-4 text-sm">Jam Operasional</h4>
              <p className="text-sm opacity-80">
                Senin - Jumat: 08:00 - 17:00<br />
                Sabtu: 08:00 - 13:00<br />
                Minggu: Tutup
              </p>
            </div>
          </motion.div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-primary-foreground/20 pt-8 text-center">
          <p className="text-sm opacity-80">
            &copy; {new Date().getFullYear()} NAMA PERUSAHAAN. Hak Cipta Dilindungi.
          </p>
        </div>
      </div>
    </footer>
  );
}
