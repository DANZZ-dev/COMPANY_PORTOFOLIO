import { motion } from 'motion/react';

export default function CompanyHero() {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      <motion.div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1760246964044-1384f71665b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1920')`,
        }}
        initial={{ scale: 1.2, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1.5, ease: "easeOut" }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 to-black/40" />
      </motion.div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center text-white">
        <motion.h1
          className="text-5xl md:text-6xl mb-6"
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          NAMA PERUSAHAAN ANDA
        </motion.h1>
        <motion.p
          className="text-xl md:text-2xl leading-relaxed opacity-90"
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          MOTTO PERUSAHAAN
        </motion.p>
      </div>
    </section>
  );
}
